import os, json, secrets, re, subprocess, atexit, time, signal
from urllib.request import urlopen
from urllib.error import URLError
from datetime import datetime, timedelta
from flask import Flask, jsonify, request, session, send_from_directory
import pandas as pd

app = Flask(__name__, static_folder='static', static_url_path='')
app.secret_key = secrets.token_hex(32)
app.permanent_session_lifetime = timedelta(hours=8)

CONFIG_PATH = os.path.join(os.path.dirname(__file__), 'datasource_config.json')

def load_config():
    try:
        with open(CONFIG_PATH) as f:
            return json.load(f)
    except:
        return {}

def get_parquet_path(key, default):
    cfg = load_config()
    base_dir = os.path.dirname(os.path.abspath(__file__))
    default_path = os.path.join(base_dir, default)
    p = cfg.get(key)
    if p:
        if not os.path.isabs(p):
            p = os.path.join(base_dir, p)
        if os.path.exists(p):
            return p
    return default_path

PARQUET_PATH = get_parquet_path('portfolios_path', 'portfolios.parquet')
GLOBALVIEW_PATH = get_parquet_path('globalview_path', 'globalview.parquet')
SHARECLASS_PATH = get_parquet_path('shareclass_path', 'globalview.parquet')
DATACONTROL_PATH = get_parquet_path('datacontrol_path', 'globalview.parquet')
OPERATIONS_PATH = get_parquet_path('operations_path', 'operations.parquet')
USERS_PORTFOLIOS_PATH = get_parquet_path('users_portfolios_path', 'users_portfolios.parquet')
USERS_PATH = get_parquet_path('users_path', 'users.parquet')
_CFG = load_config()
LLM_BACKEND = _CFG.get('llm_backend', 'gguf')
GGUF_PATH = _CFG.get('gguf_path', '')
LLAMAFILE_PATH = _CFG.get('llamafile_path', '')
LLAMAFILE_PORT = int(_CFG.get('llamafile_port', 8080))
LLAMAFILE_URL = _CFG.get('llamafile_url', f'http://localhost:{LLAMAFILE_PORT}').rstrip('/')

def _reload_config():
    global _CFG, LLM_BACKEND, GGUF_PATH, LLAMAFILE_PATH, LLAMAFILE_PORT, LLAMAFILE_URL, _LLM
    old_backend, old_gguf = LLM_BACKEND, GGUF_PATH
    _CFG = load_config()
    LLM_BACKEND = _CFG.get('llm_backend', 'gguf')
    GGUF_PATH = _CFG.get('gguf_path', '')
    LLAMAFILE_PATH = _CFG.get('llamafile_path', '')
    LLAMAFILE_PORT = int(_CFG.get('llamafile_port', 8080))
    LLAMAFILE_URL = _CFG.get('llamafile_url', f'http://localhost:{LLAMAFILE_PORT}').rstrip('/')
    if LLM_BACKEND != old_backend or GGUF_PATH != old_gguf:
        _LLM = None

DEFAULT_USERS = [
    {'username': 'admin', 'password': 'admin123', 'role': 'admin', 'client_id': ''},
    {'username': 'hamdi', 'password': 'hamdi123', 'role': 'user', 'client_id': 'client_hamdi'},
]

def load_users():
    return df_to_json(_read_df(USERS_PATH)) or list(DEFAULT_USERS)

def save_users(records):
    df = pd.DataFrame(records)
    df.to_parquet(USERS_PATH, index=False)

def get_user_dict():
    users = load_users()
    return {u['username']: u for u in users}

CLIENTS = [
    {"id": "client_hamdi", "name": "Hamdi", "email": "hamdi@example.com", "phone": "+33 6 00 00 00 00", "risk_profile": "moderate", "notes": ""},
]

SECTORS = [
    "A\u00e9ro & D\u00e9fense", "Automobile", "Consommation", "Coop\u00e9ratif",
    "Cybers\u00e9curit\u00e9", "Finance", "Fonds", "Industrie",
    "Infrastructure", "Luxe", "Mati\u00e8res premi\u00e8res",
    "Semi-conducteurs", "Services publics", "Sant\u00e9",
    "Technologie", "T\u00e9l\u00e9com", "\u00c9nergie"
]

COUNTRIES = ["CH", "CN", "DE", "FR", "IE", "IT", "NL", "TW", "UK", "US"]

BENCHMARKS = [
    {"id": 1, "name": "Euro Stoxx 50", "components": [{"ticker": "^STOXX50E", "label": "Euro Stoxx 50", "weight": 50}, {"ticker": "^FCHI", "label": "CAC 40", "weight": 25}, {"ticker": "^GDAXI", "label": "DAX", "weight": 25}]}
]

def df_to_json(df):
    df = df.astype(object)
    for col in df.columns:
        mask = df[col].isna()
        if mask.any():
            df.loc[mask, col] = None
    return df.to_dict('records')

def _read_df(path):
    try:
        return pd.read_parquet(path)
    except Exception:
        return pd.DataFrame()

def load_portfolios():
    try:
        df = pd.read_parquet(PARQUET_PATH)
    except:
        return []
    df = df.copy()
    UG_COLUMNS = ('ug', 'unitegestion', 'unite_gestion', 'unite_de_gestion', 'unite-gestion', 'UG')
    OG_COLUMNS = ('og', 'orientationgestion', 'orientation_gestion', 'orientation_de_gestion', 'orientation-gestion', 'OG')
    def _norm_group(aliases, target):
        col = next((c for c in aliases if c in df.columns), None)
        if col is not None:
            if col != target:
                df[target] = df[col]
        elif target not in df.columns:
            df[target] = None
    _norm_group(UG_COLUMNS, 'ug')
    _norm_group(OG_COLUMNS, 'og')
    return df_to_json(df)

def save_portfolios(portfolios):
    df = pd.DataFrame(portfolios)
    df.to_parquet(PARQUET_PATH, index=False)

def load_user_portfolios():
    return df_to_json(_read_df(USERS_PORTFOLIOS_PATH))

def save_user_portfolios(records):
    df = pd.DataFrame(records)
    df.to_parquet(USERS_PORTFOLIOS_PATH, index=False)

def login_required(f):
    from functools import wraps
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user' not in session:
            return jsonify({"error": "Unauthorized", "login_required": True}), 401
        return f(*args, **kwargs)
    return decorated

def get_allowed_portfolio_ids():
    """Return set of portfolio IDs the current user has access to. None means unrestricted (admin)."""
    username = session.get('user')
    role = session.get('role')
    if not username or role == 'admin':
        return None
    records = load_user_portfolios()
    user_records = [r for r in records if r.get('username') == username]
    if not user_records:
        return set()
    allowed = set()
    portfolios = load_portfolios()
    for r in user_records:
        atype = r.get('association_type', '')
        avalue = r.get('association_value', '')
        if atype == 'name' and avalue:
            allowed.add(avalue)
        elif atype == 'ug' and avalue:
            for p in portfolios:
                if (p.get('ug') or '').strip() == avalue.strip():
                    allowed.add(p['id'])
        elif atype == 'manager' and avalue:
            for p in portfolios:
                if (p.get('fund_manager') or '').strip() == avalue.strip():
                    allowed.add(p['id'])
    return allowed

@app.route('/api/login', methods=['POST'])
def api_login():
    data = request.get_json()
    username = data.get('username', '').strip().lower()
    password = data.get('password', '')
    users_dict = get_user_dict()
    user = users_dict.get(username)
    if not user or user.get('password', '') != password:
        return jsonify({"error": "Invalid credentials"}), 401
    session['user'] = username
    session['role'] = user.get('role', 'user')
    session['client_id'] = user.get('client_id')
    return jsonify({"username": username, "role": user.get('role', 'user'), "client_id": user.get('client_id')})

@app.route('/api/logout', methods=['POST'])
def api_logout():
    session.clear()
    return jsonify({"ok": True})

@app.route('/api/me')
@login_required
def api_me():
    return jsonify({"username": session['user'], "role": session['role'], "client_id": session.get('client_id')})

@app.route('/api/portfolio')
@login_required
def api_portfolio():
    portfolios = load_portfolios()
    allowed = get_allowed_portfolio_ids()
    if allowed is not None:
        portfolios = [p for p in portfolios if p.get('id') in allowed]
    return jsonify(portfolios)

@app.route('/api/portfolio', methods=['POST'])
@login_required
def api_create_portfolio():
    data = request.get_json()
    pid = (data.get('fund_code') or '').strip()
    if not pid:
        pid = f"fund_{secrets.token_hex(4)}"
    pf = {
        "id": pid,
        "fund_code": data.get('fund_code', ''),
        "fund_name": data.get('fund_name', ''),
        "fund_currency": data.get('fund_currency', 'EUR'),
        "fund_manager": data.get('fund_manager', ''),
        "custodian": data.get('custodian', ''),
        "entity": data.get('entity', ''),
        "classification": data.get('classification', ''),
        "ug": data.get('ug', ''),
        "og": data.get('og', ''),
        "portfolio_year": data.get('portfolio_year', None),
        "initial_aum": data.get('initial_aum', None),
        "created_at": datetime.now().isoformat()
    }
    portfolios = load_portfolios()
    portfolios.append(pf)
    save_portfolios(portfolios)
    return jsonify(pf), 201

@app.route('/api/portfolio/<portfolio_id>', methods=['DELETE'])
@login_required
def api_delete_portfolio(portfolio_id):
    portfolios = load_portfolios()
    portfolios = [p for p in portfolios if p['id'] != portfolio_id]
    save_portfolios(portfolios)
    return jsonify({"ok": True})

@app.route('/api/globalview')
@login_required
def api_globalview():
    fund_name = request.args.get('fund_name', '')
    asset_manager = request.args.get('asset_manager', '')
    df = _read_df(GLOBALVIEW_PATH)
    if fund_name:
        df = df[df['fund_name'] == fund_name]
    if asset_manager:
        df = df[df['asset_manager'] == asset_manager]
    return jsonify(df_to_json(df))

@app.route('/api/shareclass')
@login_required
def api_shareclass():
    return jsonify(df_to_json(_read_df(SHARECLASS_PATH)))

@app.route('/api/operations')
@login_required
def api_operations():
    fund_id = request.args.get('fund_id', '')
    date_from = request.args.get('from', '')
    date_to = request.args.get('to', '')
    df = _read_df(OPERATIONS_PATH)
    allowed = get_allowed_portfolio_ids()
    if allowed is not None:
        df = df[df['fund_id'].isin(allowed)]
    if fund_id:
        df = df[df['fund_id'] == fund_id]
    if 'date' in df.columns:
        if date_from:
            df = df[df['date'].astype(str) >= date_from]
        if date_to:
            df = df[df['date'].astype(str) <= date_to]
    return jsonify(df_to_json(df))

@app.route('/api/portfolio/export')
@login_required
def api_portfolio_export():
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    from openpyxl.utils import get_column_letter
    import io
    headers = ['Fund Code', 'Fund Name', 'Fund Currency', 'Fund Manager', 'Custodian', 'Entity', 'Classification', 'UG', 'OG', 'Portfolio Year', 'Initial AuM', 'Created']
    portfolios = load_portfolios()
    wb = Workbook()
    ws = wb.active
    ws.title = 'Portfolios'
    ws.append(headers)
    hdr_fill = PatternFill(start_color='2563EB', end_color='2563EB', fill_type='solid')
    hdr_font = Font(bold=True, color='FFFFFF', size=10)
    stripe = [PatternFill(start_color='EDF2FF', end_color='EDF2FF', fill_type='solid'), PatternFill(start_color='FFFFFF', end_color='FFFFFF', fill_type='solid')]
    thin = Side(style='thin', color='E5E7EB')
    bdr = Border(bottom=thin)
    for c in range(1, len(headers) + 1):
        cell = ws.cell(row=1, column=c)
        cell.font = hdr_font
        cell.fill = hdr_fill
        cell.alignment = Alignment(horizontal='center', vertical='center')
    for ri, p in enumerate(portfolios, start=2):
        vals = [p.get('fund_code',''), p.get('fund_name',''), p.get('fund_currency',''), p.get('fund_manager',''), p.get('custodian',''), p.get('entity',''), p.get('classification',''), p.get('ug',''), p.get('og',''), p.get('portfolio_year',''), p.get('initial_aum',''), p.get('created_at','')]
        ws.append(vals)
        fill = stripe[(ri - 2) % 2]
        for c in range(1, len(headers) + 1):
            cell = ws.cell(row=ri, column=c)
            cell.fill = fill
            cell.border = bdr
    for i, h in enumerate(headers, 1):
        col = get_column_letter(i)
        lengths = [len(h)] + [len(str(r[i-1])) for r in ws.iter_rows(min_row=2, values_only=True) if r[i-1] is not None]
        maxlen = max(lengths)
        ws.column_dimensions[col].width = min(max(maxlen + 2, 10), 40)
    ws.freeze_panes = 'A2'
    if len(portfolios) > 0:
        last_col = get_column_letter(len(headers))
        ws.auto_filter.ref = f'A1:{last_col}{len(portfolios) + 1}'
    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return buf.getvalue(), 200, {'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'Content-Disposition': 'attachment; filename=portfolios.xlsx'}

@app.route('/api/dashboard')
@login_required
def api_dashboard():
    portfolios = load_portfolios()
    allowed = get_allowed_portfolio_ids()
    if allowed is not None:
        portfolios = [p for p in portfolios if p.get('id') in allowed]
    gv_df = _read_df(GLOBALVIEW_PATH)
    if not gv_df.empty and 'fund_name' in gv_df.columns:
        if allowed is not None:
            allowed_names = set(p.get('fund_name') or '' for p in portfolios)
            gv_df = gv_df[gv_df['fund_name'].isin(allowed_names)]

    total_aum = gv_df['total_market_value'].sum() if not gv_df.empty and 'total_market_value' in gv_df.columns else 0
    total_positions = len(gv_df)

    by_fund = gv_df.groupby('fund_name')['total_market_value'].sum() if not gv_df.empty and 'fund_name' in gv_df.columns else {}

    for p in portfolios:
        pid = p.get('id', '')
        pf_name = p.get('fund_name', '')
        ph = gv_df[gv_df['fund_name'] == pf_name] if not gv_df.empty and 'fund_name' in gv_df.columns else pd.DataFrame()
        p['name'] = p.pop('fund_name', p.get('fund_code', ''))
        p['type'] = p.pop('classification', 'Custom')
        p['aum'] = round(float(ph['total_market_value'].sum()), 2) if not ph.empty else 0
        p['pnl'] = 0
        p['position_count'] = len(ph)
        p['esg_score'] = None
        portfolio_year = p.get('portfolio_year')
        initial_aum = p.get('initial_aum')
        if portfolio_year is not None and initial_aum is not None:
            try:
                init_val = float(initial_aum)
                if init_val != 0:
                    p['performance'] = round((p['aum'] - init_val) / init_val * 100, 2)
                else:
                    p['performance'] = None
            except (ValueError, TypeError):
                p['performance'] = None
        else:
            p['performance'] = None

    return jsonify({
        "portfolios": portfolios,
        "total_value": len(portfolios),
        "total_aum": round(float(total_aum), 2),
        "total_pnl": 0,
        "avg_esg": None,
        "positions_count": total_positions,
        "clients": CLIENTS
    })

@app.route('/api/sectors')
@login_required
def api_sectors():
    return jsonify(SECTORS)

@app.route('/api/countries')
@login_required
def api_countries():
    return jsonify(COUNTRIES)

@app.route('/api/clients')
@login_required
def api_clients():
    return jsonify(CLIENTS)

@app.route('/api/clients', methods=['POST'])
@login_required
def api_create_client():
    data = request.get_json()
    cid = f"client_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{secrets.token_hex(3)}"
    client = {"id": cid, "name": data.get('name', ''), "email": data.get('email', ''), "phone": data.get('phone', ''), "risk_profile": data.get('risk_profile', 'moderate'), "notes": data.get('notes', '')}
    CLIENTS.append(client)
    return jsonify(client), 201

@app.route('/api/users-portfolios')
@login_required
def api_list_user_portfolios():
    records = load_user_portfolios()
    allowed = get_allowed_portfolio_ids()
    portfolios = load_portfolios()
    if allowed is not None:
        portfolios = [p for p in portfolios if p.get('id') in allowed]
    portfolio_map = {p['id']: p for p in portfolios}
    ug_portfolios = {}
    mgr_portfolios = {}
    for p in portfolios:
        ug = (p.get('ug') or '').strip()
        if ug:
            ug_portfolios.setdefault(ug, []).append(p['id'])
        mgr = (p.get('fund_manager') or '').strip()
        if mgr:
            mgr_portfolios.setdefault(mgr, []).append(p['id'])
    result = []
    for r in records:
        username = r.get('username', '')
        assoc_type = r.get('association_type', '')
        assoc_value = r.get('association_value', '')
        if assoc_type == 'ug':
            matched_ids = ug_portfolios.get(assoc_value.strip(), [])
            for pid in matched_ids:
                p = portfolio_map.get(pid, {})
                result.append({
                    'username': username,
                    'association_type': 'ug',
                    'association_value': assoc_value,
                    'portfolio_id': pid,
                    'portfolio_name': p.get('fund_name') or p.get('fund_code') or pid,
                    'ug': p.get('ug', ''),
                    'og': p.get('og', ''),
                    'fund_manager': p.get('fund_manager', '')
                })
        elif assoc_type == 'manager':
            matched_ids = mgr_portfolios.get(assoc_value.strip(), [])
            for pid in matched_ids:
                p = portfolio_map.get(pid, {})
                result.append({
                    'username': username,
                    'association_type': 'manager',
                    'association_value': assoc_value,
                    'portfolio_id': pid,
                    'portfolio_name': p.get('fund_name') or p.get('fund_code') or pid,
                    'ug': p.get('ug', ''),
                    'og': p.get('og', ''),
                    'fund_manager': p.get('fund_manager', '')
                })
        else:
            p = portfolio_map.get(assoc_value, {})
            result.append({
                'username': username,
                'association_type': 'name',
                'association_value': assoc_value,
                'portfolio_id': assoc_value,
                'portfolio_name': p.get('fund_name') or p.get('fund_code') or assoc_value,
                'ug': p.get('ug', ''),
                'og': p.get('og', ''),
                'fund_manager': p.get('fund_manager', '')
            })
    return jsonify(result)

@app.route('/api/users-portfolios', methods=['POST'])
@login_required
def api_set_user_portfolios():
    data = request.get_json() or {}
    username = data.get('username', '').strip().lower()
    if not username:
        return jsonify({"error": "username is required"}), 400
    by_name = data.get('by_name', [])
    by_ug = data.get('by_ug', [])
    by_manager = data.get('by_manager', [])
    records = load_user_portfolios()
    records = [r for r in records if r.get('username') != username]
    for name in by_name:
        name = name.strip()
        if name:
            records.append({'username': username, 'association_type': 'name', 'association_value': name})
    for ug in by_ug:
        ug = ug.strip()
        if ug:
            records.append({'username': username, 'association_type': 'ug', 'association_value': ug})
    for mgr in by_manager:
        mgr = mgr.strip()
        if mgr:
            records.append({'username': username, 'association_type': 'manager', 'association_value': mgr})
    save_user_portfolios(records)
    return jsonify({"ok": True, "username": username, "by_name": by_name, "by_ug": by_ug, "by_manager": by_manager})

@app.route('/api/users-portfolios/<username>', methods=['DELETE'])
@login_required
def api_delete_user_portfolios(username):
    username = username.strip().lower()
    records = load_user_portfolios()
    records = [r for r in records if r.get('username') != username]
    save_user_portfolios(records)
    return jsonify({"ok": True})

@app.route('/api/users-portfolios/ugs')
@login_required
def api_list_ugs():
    portfolios = load_portfolios()
    ugs = sorted(set((p.get('ug') or '').strip() for p in portfolios if (p.get('ug') or '').strip()))
    return jsonify(ugs)

@app.route('/api/users-portfolios/managers')
@login_required
def api_list_managers():
    portfolios = load_portfolios()
    managers = sorted(set((p.get('fund_manager') or '').strip() for p in portfolios if (p.get('fund_manager') or '').strip()))
    return jsonify(managers)

@app.route('/api/users')
@login_required
def api_list_users():
    users = load_users()
    return jsonify([{'username': u.get('username', ''), 'role': u.get('role', ''), 'client_id': u.get('client_id', '')} for u in users])

@app.route('/api/users', methods=['POST'])
@login_required
def api_create_user():
    data = request.get_json() or {}
    username = data.get('username', '').strip().lower()
    password = data.get('password', '').strip()
    role = data.get('role', 'user').strip()
    client_id = data.get('client_id', '').strip()
    if not username or not password:
        return jsonify({"error": "username and password are required"}), 400
    users = load_users()
    if any(u.get('username') == username for u in users):
        return jsonify({"error": "User already exists"}), 409
    users.append({'username': username, 'password': password, 'role': role, 'client_id': client_id})
    save_users(users)
    return jsonify({"ok": True, "username": username}), 201

@app.route('/api/users/<username>', methods=['PUT'])
@login_required
def api_update_user(username):
    username = username.strip().lower()
    data = request.get_json() or {}
    users = load_users()
    found = False
    for u in users:
        if u.get('username') == username:
            if 'password' in data and data['password'].strip():
                u['password'] = data['password'].strip()
            if 'role' in data:
                u['role'] = data['role'].strip()
            if 'client_id' in data:
                u['client_id'] = data['client_id'].strip()
            found = True
            break
    if not found:
        return jsonify({"error": "User not found"}), 404
    save_users(users)
    return jsonify({"ok": True})

@app.route('/api/users/<username>', methods=['DELETE'])
@login_required
def api_delete_user(username):
    username = username.strip().lower()
    users = load_users()
    users = [u for u in users if u.get('username') != username]
    save_users(users)
    records = load_user_portfolios()
    records = [r for r in records if r.get('username') != username]
    save_user_portfolios(records)
    return jsonify({"ok": True})

@app.route('/api/config/benchmarks', methods=['GET', 'POST'])
@login_required
def api_benchmarks():
    if request.method == 'POST':
        data = request.get_json()
        bm = {"id": len(BENCHMARKS) + 1, "name": data.get('name', 'New Benchmark'), "components": data.get('components', [])}
        BENCHMARKS.append(bm)
        return jsonify(bm), 201
    return jsonify(BENCHMARKS)

def _build_report_data():
    """Build the factsheet data dict shared by JSON and Excel endpoints."""
    portfolio_id = request.args.get('portfolio', '')
    portfolios = load_portfolios()
    allowed = get_allowed_portfolio_ids()
    if allowed is not None:
        portfolios = [p for p in portfolios if p.get('id') in allowed]
    pf = None
    if portfolio_id:
        pf = next((p for p in portfolios if p.get('id') == portfolio_id), None)

    gv_df = _read_df(DATACONTROL_PATH)
    if not gv_df.empty and allowed is not None:
        allowed_names = set(p.get('fund_name') or '' for p in portfolios)
        gv_df = gv_df[gv_df['fund_name'].isin(allowed_names)]
    if not gv_df.empty and portfolio_id:
        pf_name = (pf or {}).get('fund_name', '')
        if pf_name:
            gv_df = gv_df[gv_df['fund_name'] == pf_name]

    holdings = df_to_json(gv_df) if not gv_df.empty else []

    total_aum = round(float(gv_df['total_market_value'].sum()), 2) if not gv_df.empty else 0
    position_count = len(holdings)

    top10 = sorted(holdings, key=lambda h: float(h.get('total_market_value') or 0), reverse=True)[:10]

    asset_alloc = {}
    for h in holdings:
        mv = float(h.get('total_market_value') or 0)
        mt = h.get('management_type') or 'Autre'
        asset_alloc[mt] = asset_alloc.get(mt, 0) + mv

    approved_etf_val = sum(float(h.get('total_market_value') or 0) for h in holdings if h.get('approved_etf'))
    approved_fund_val = sum(float(h.get('total_market_value') or 0) for h in holdings if h.get('approved_fund'))

    def _alloc_list(d):
        items = [{"name": k, "value": round(v, 2), "pct": round(v / total_aum * 100, 1) if total_aum else 0} for k, v in d.items()]
        return sorted(items, key=lambda x: -x['value'])

    performance = None
    if pf:
        py = pf.get('portfolio_year')
        ia = pf.get('initial_aum')
        if py is not None and ia is not None:
            try:
                init_val = float(ia)
                if init_val != 0:
                    performance = round((total_aum - init_val) / init_val * 100, 2)
            except (ValueError, TypeError):
                pass

    period = request.args.get('period', '1Y')
    period_label = {'1M': '1 Mois', '3M': '3 Mois', '6M': '6 Mois', '1Y': '1 An', 'YTD': 'YTD'}.get(period, period)

    return {
        "portfolio": pf,
        "portfolios": portfolios,
        "clients": CLIENTS,
        "holdings": holdings,
        "top10": top10,
        "total_aum": total_aum,
        "total_pnl": 0,
        "position_count": position_count,
        "avg_esg": None,
        "performance": performance,
        "asset_allocation": _alloc_list(asset_alloc),
        "geo_allocation": [],
        "sector_allocation": [],
        "equity_pct": round(approved_fund_val / total_aum * 100, 1) if total_aum else 0,
        "bond_pct": round(approved_etf_val / total_aum * 100, 1) if total_aum else 0,
        "avg_pe": None,
        "dividend_yield": None,
        "benchmark": BENCHMARKS[0] if BENCHMARKS else None,
        "generated_at": datetime.now().strftime('%d/%m/%Y'),
        "period_label": period_label,
    }


@app.route('/api/report')
@login_required
def api_report():
    return jsonify(_build_report_data())


@app.route('/api/report/excel')
@login_required
def api_report_excel():
    from flask import send_file
    from excel_export import generate_excel
    data = _build_report_data()
    xlsx_bytes = generate_excel(data)
    filename = f'factsheet_{data["portfolio"].get("fund_code", "report")}_{data["generated_at"].replace("/", "")}.xlsx' if data['portfolio'] else 'factsheet.xlsx'
    return send_file(
        __import__('io').BytesIO(xlsx_bytes),
        mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        as_attachment=True,
        download_name=filename,
    )


@app.route('/api/config/datasource', methods=['GET', 'POST'])
def api_datasource_config():
    if request.method == 'POST':
        data = request.get_json()
        with open(CONFIG_PATH, 'w') as f:
            json.dump(data, f)
        _reload_config()
        return jsonify({"ok": True})
    cfg = load_config()
    return jsonify(cfg)

@app.route('/')
def index():
    return send_from_directory('static', 'index.html')

@app.route('/<path:path>')
def static_files(path):
    if path in ['documentation', 'data-model', 'simple']:
        return send_from_directory('static', 'index.html')
    try:
        return send_from_directory('static', path)
    except:
        return send_from_directory('static', 'index.html')

_LLM = None

def _get_llm():
    global _LLM
    if _LLM is None:
        if not GGUF_PATH or not os.path.exists(GGUF_PATH):
            raise RuntimeError("GGUF model not found. Set 'gguf_path' in datasource_config.json")
        from llama_cpp import Llama
        _LLM = Llama(model_path=GGUF_PATH, n_ctx=4096, n_threads=os.cpu_count() or 4, verbose=False)
    return _LLM

def _llamafile_chat(messages, max_tokens=600, temperature=0.3):
    import urllib.request, urllib.error
    payload = json.dumps({"model": "llamafile", "messages": messages, "max_tokens": max_tokens, "temperature": temperature}).encode()
    req = urllib.request.Request(f"{LLAMAFILE_URL}/v1/chat/completions", data=payload, headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            return json.loads(resp.read())
    except urllib.error.URLError as e:
        raise RuntimeError(f"Llamafile server unreachable ({LLAMAFILE_URL}): {e}")

def _build_ai_context():
    """Return a compact text summary of the user's portfolios as grounding for the AI."""
    allowed = get_allowed_portfolio_ids()
    portfolios = load_portfolios()
    if allowed is not None:
        portfolios = [p for p in portfolios if p.get('id') in allowed]
    gv_df = _read_df(GLOBALVIEW_PATH)
    if not gv_df.empty and allowed is not None:
        allowed_names = set(p.get('fund_name') or '' for p in portfolios)
        gv_df = gv_df[gv_df['fund_name'].isin(allowed_names)]
    rows = df_to_json(gv_df) if not gv_df.empty else []
    lines = ["PORTEFEUILLES:"]
    for p in portfolios:
        lines.append(f"- {p.get('fund_name') or p.get('fund_code') or p.get('id')} | UG: {p.get('ug') or '-'} | OG: {p.get('og') or '-'} | Manager: {p.get('fund_manager') or '-'} | Devise: {p.get('fund_currency') or '-'}")
    lines.append(f"TOTAL PORTEFEUILLES: {len(portfolios)}")
    lines.append("POSITIONS (GLOBALVIEW):")
    by_fund = {}
    for h in rows:
        by_fund.setdefault(h.get('fund_name'), []).append(h)
    for fname, hs in by_fund.items():
        mv = sum(float(h.get('total_market_value') or 0) for h in hs)
        qty = sum(float(h.get('total_quantity') or 0) for h in hs)
        lines.append(f"- {fname} ({len(hs)} lignes, mkt val {mv:,.0f}, qty totale {qty:,.0f})")
    for h in sorted(rows, key=lambda x: float(x.get('total_market_value') or 0), reverse=True)[:25]:
        lines.append(f"  * {h.get('isin') or h.get('security_name')} | {h.get('security_name') or '-'} | Gestionnaire: {h.get('asset_manager') or '-'} | Type: {h.get('management_type') or '-'} | Approuvé ETF: {h.get('approved_etf') or '-'} | Approuvé Fund: {h.get('approved_fund') or '-'} | mkt {float(h.get('total_market_value') or 0):,.0f}")
    return "\n".join(lines)

@app.route('/api/ai/chat', methods=['POST'])
@login_required
def api_ai_chat():
    data = request.get_json(silent=True) or {}
    question = (data.get('question') or '').strip()
    history = data.get('history') or []
    if not question:
        return jsonify({"error": "Question is required"}), 400
    context = _build_ai_context()
    messages = [{
        "role": "system",
        "content": ("Tu es un assistant d'investissement qui aide l'utilisateur à comprendre son portefeuille. "
                    "Base-toi uniquement sur le contexte fourni (portefeuilles et positions) et sur des principes financiers généraux. "
                    "Réponds en français, de façon concise et structurée. Si l'information n'est pas dans le contexte, dis-le.\n\n"
                    "CONTEXTE DU PORTEFEUILLE:\n" + context)
    }]
    messages += history[-8:]
    messages.append({"role": "user", "content": question})
    try:
        if LLM_BACKEND == 'llamafile':
            out = _llamafile_chat(messages)
        else:
            llm = _get_llm()
            out = llm.create_chat_completion(messages, max_tokens=600, temperature=0.3)
    except (RuntimeError, Exception) as e:
        return jsonify({"error": str(e)}), 500
    try:
        answer = out['choices'][0]['message']['content'].strip()
    except (KeyError, IndexError):
        return jsonify({"error": "No response from model"}), 500
    return jsonify({"answer": answer})

@app.route('/api/ai/model')
@login_required
def api_ai_model():
    if LLM_BACKEND == 'llamafile':
        available = bool(LLAMAFILE_URL)
        loaded = False
        if available:
            try:
                import urllib.request
                urllib.request.urlopen(f"{LLAMAFILE_URL}/v1/models", timeout=3)
                loaded = True
            except Exception:
                pass
        return jsonify({"backend": "llamafile", "url": LLAMAFILE_URL, "loaded": loaded, "available": available})
    return jsonify({"backend": "gguf", "path": GGUF_PATH, "loaded": _LLM is not None, "available": bool(GGUF_PATH and os.path.exists(GGUF_PATH))})

_LLAMAFILE_PROC = None

def _start_llamafile():
    global _LLAMAFILE_PROC
    if not LLAMAFILE_PATH or not os.path.exists(LLAMAFILE_PATH):
        return
    if _LLAMAFILE_PROC is not None and _LLAMAFILE_PROC.poll() is None:
        return
    try:
        urlopen(f'{LLAMAFILE_URL}/v1/models', timeout=2)
        print(f'[llamafile] already running on {LLAMAFILE_URL}')
        return
    except Exception:
        pass
    try:
        kwargs = dict(stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        if os.name == 'nt':
            kwargs['creationflags'] = subprocess.CREATE_NEW_PROCESS_GROUP
        else:
            kwargs['preexec_fn'] = os.setsid
        _LLAMAFILE_PROC = subprocess.Popen(
            [LLAMAFILE_PATH, '--server', '--model', os.path.join(os.path.dirname(LLAMAFILE_PATH), 'Llama-3.2-3B-Instruct-Q4_K_M.gguf'), '--port', str(LLAMAFILE_PORT), '--host', '0.0.0.0'],
            **kwargs,
        )
    except OSError as e:
        print(f'[llamafile] could not auto-start: {e}')
        print(f'[llamafile] start it manually: {LLAMAFILE_PATH} --server --model <model.gguf> --port {LLAMAFILE_PORT}')
        return
    for _ in range(30):
        try:
            urlopen(f'{LLAMAFILE_URL}/v1/models', timeout=2)
            print(f'[llamafile] ready on port {LLAMAFILE_PORT}')
            return
        except (URLError, OSError):
            time.sleep(1)
    print(f'[llamafile] WARNING: server started but not responding after 30s')

def _stop_llamafile():
    global _LLAMAFILE_PROC
    if _LLAMAFILE_PROC is None:
        return
    try:
        if os.name == 'nt':
            _LLAMAFILE_PROC.terminate()
            _LLAMAFILE_PROC.wait(timeout=5)
        else:
            os.killpg(os.getpgid(_LLAMAFILE_PROC.pid), signal.SIGTERM)
            _LLAMAFILE_PROC.wait(timeout=5)
    except Exception:
        try:
            if os.name == 'nt':
                _LLAMAFILE_PROC.kill()
            else:
                os.killpg(os.getpgid(_LLAMAFILE_PROC.pid), signal.SIGKILL)
        except Exception:
            pass
    _LLAMAFILE_PROC = None

atexit.register(_stop_llamafile)

if __name__ == '__main__':
    if LLM_BACKEND == 'llamafile':
        _start_llamafile()
    app.run(host='0.0.0.0', port=5000)
