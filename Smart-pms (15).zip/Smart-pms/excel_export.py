from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from openpyxl.chart import PieChart, Reference
from openpyxl.chart.label import DataLabelList
from openpyxl.chart.series import DataPoint
from datetime import datetime

ASSET_COLORS = ['2E7D32', '66BB6A', 'A5D6A7', '1B5E20', '81C784', '4CAF50', '388E3C', 'C8E6C9', '43A047', '00C853']
GEO_COLORS = ['1565C0', '42A5F5', '90CAF9', '0D47A1', '1E88E5', '64B5F6', '2196F3', '03A9F4', 'BBDEFB', 'E3F2FD']
SECT_COLORS = ['E65100', 'FF9800', 'FFB74D', 'BF360C', 'FB8C00', 'F57C00', 'EF6C00', 'FFE0B2', 'FF8F00', 'FFA726']
FALLBACK_COLORS = ['1565C0', '42A5F5', '90CAF9', 'BBDEFB', '2E7D32', '66BB6A', 'E65100', 'FF9800', '7B1FA2', 'CE93D8']

COLOR_MAP = {'asset': ASSET_COLORS, 'geo': GEO_COLORS, 'sector': SECT_COLORS}



HEADER_FILL = PatternFill(start_color='0F1923', end_color='0F1923', fill_type='solid')
HEADER_FONT = Font(name='Calibri', size=14, bold=True, color='FFFFFF')
SUB_FILL = PatternFill(start_color='1A2A3A', end_color='1A2A3A', fill_type='solid')
SUB_FONT = Font(name='Calibri', size=10, color='FFFFFF')
KPI_FILL = PatternFill(start_color='F1F5F9', end_color='F1F5F9', fill_type='solid')
KPI_FONT = Font(name='Calibri', size=11, bold=True, color='0F1923')
KPI_LBL = Font(name='Calibri', size=9, color='888888')
SEC_FONT = Font(name='Calibri', size=11, bold=True, color='0F1923')
TH_FILL = PatternFill(start_color='E3F2FD', end_color='E3F2FD', fill_type='solid')
TH_FONT = Font(name='Calibri', size=10, bold=True, color='1565C0')
TD_FONT = Font(name='Calibri', size=10, color='333333')
BORDER = Border(bottom=Side(style='thin', color='E9ECEF'))
BLUE = Font(name='Calibri', size=10, bold=True, color='1565C0')
RED = Font(name='Calibri', size=10, bold=True, color='DC3545')
META_FONT = Font(name='Calibri', size=9, color='FFFFFF')
BOLD = Font(name='Calibri', size=10, bold=True)


def _fill_row(ws, row, ncols, fill):
    for c in range(1, ncols + 1):
        ws.cell(row=row, column=c).fill = fill


def _table_header(ws, row, headers):
    for i, h in enumerate(headers, 1):
        c = ws.cell(row=row, column=i, value=h)
        c.font = TH_FONT
        c.fill = TH_FILL
        c.border = BORDER


def build_worksheet(ws, data, num_fmt='#,##0.00'):
    ws.title = 'Factsheet'
    ws.sheet_properties.tabColor = '0F1923'

    for ci in range(1, 13):
        ws.column_dimensions[get_column_letter(ci)].width = 16
    ws.column_dimensions['A'].width = 5
    ws.column_dimensions['B'].width = 30

    pf = data.get('portfolio') or {}
    fund_name = pf.get('fund_name', '')
    fund_code = pf.get('fund_code', '')
    fund_currency = pf.get('fund_currency', 'EUR')
    fund_manager = pf.get('fund_manager', '')
    classification = pf.get('classification', '')
    total_aum = data.get('total_aum', 0)
    total_pnl = data.get('total_pnl', 0)
    position_count = data.get('position_count', 0)
    avg_esg = data.get('avg_esg')
    performance = data.get('performance')
    top10 = data.get('top10', [])
    equity_pct = data.get('equity_pct', 0)
    bond_pct = data.get('bond_pct', 0)
    period_label = data.get('period_label', '1 An')
    generated_at = data.get('generated_at', datetime.now().strftime('%d/%m/%Y'))

    row = 1

    # === HEADER ===
    ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=9)
    c = ws.cell(row=row, column=1, value=fund_name)
    c.font = HEADER_FONT
    c.fill = HEADER_FILL
    c.alignment = Alignment(vertical='center')
    ws.row_dimensions[row].height = 36
    _fill_row(ws, row, 9, HEADER_FILL)
    row += 1

    ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=9)
    c = ws.cell(row=row, column=1, value=f'REPORTING MENSUEL \u2014 {period_label} | {generated_at}')
    c.font = SUB_FONT
    c.fill = SUB_FILL
    c.alignment = Alignment(vertical='center')
    ws.row_dimensions[row].height = 22
    _fill_row(ws, row, 9, SUB_FILL)
    row += 1

    ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=9)
    c = ws.cell(row=row, column=1, value=f'Code: {fund_code}  |  Devise: {fund_currency}  |  Gestionnaire: {fund_manager}  |  Classification: {classification}')
    c.font = META_FONT
    c.fill = SUB_FILL
    ws.row_dimensions[row].height = 18
    _fill_row(ws, row, 9, SUB_FILL)
    row += 2

    # === KPIs ===
    kpis = [
        ('Actif Total', f'{total_aum:,.2f} {fund_currency}'),
        ('P&L Total', f'{total_pnl:,.2f}'),
        ('Performance', f'{("+" if performance and performance >= 0 else "")}{performance:.2f}%' if performance is not None else '--'),
        ('Score ESG', f'{avg_esg:.1f}' if avg_esg is not None else '--'),
        ('Positions', str(position_count)),
    ]
    for i, (lbl, val) in enumerate(kpis):
        col = i + 1
        cv = ws.cell(row=row, column=col, value=val)
        cv.font = KPI_FONT
        cv.fill = KPI_FILL
        cv.alignment = Alignment(horizontal='center')
        cl = ws.cell(row=row + 1, column=col, value=lbl)
        cl.font = KPI_LBL
        cl.fill = KPI_FILL
        cl.alignment = Alignment(horizontal='center')
    row += 3

    # === PERFORMANCE ===
    ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=9)
    ws.cell(row=row, column=1, value='PERFORMANCES (nettes de frais)').font = SEC_FONT
    row += 1
    _table_header(ws, row, ['', 'P\u00e9riode', 'P&L', 'Performance'])
    row += 1
    ws.cell(row=row, column=1, value=1).font = TD_FONT
    ws.cell(row=row, column=2, value=fund_name).font = BOLD
    ws.cell(row=row, column=3, value=period_label).font = TD_FONT
    pc = ws.cell(row=row, column=4, value=total_pnl)
    pc.font = BLUE if total_pnl >= 0 else RED
    pc.number_format = num_fmt
    pp = ws.cell(row=row, column=5, value=f'{performance:.2f}%' if performance is not None else '--')
    pp.font = BLUE if performance and performance >= 0 else RED
    row += 2

    # === TOP 10 HOLDINGS ===
    ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=9)
    ws.cell(row=row, column=1, value='PRINCIPALES POSITIONS (en % de l\'actif net)').font = SEC_FONT
    row += 1
    _table_header(ws, row, ['#', 'Instrument', 'Ticker', 'Cat\u00e9gorie', 'Poids', 'Valeur Marchande'])
    row += 1
    for i, h in enumerate(top10):
        ws.cell(row=row, column=1, value=i + 1).font = TD_FONT
        ws.cell(row=row, column=2, value=h.get('name', '')).font = TD_FONT
        ws.cell(row=row, column=3, value=h.get('ticker', '')).font = TD_FONT
        ws.cell(row=row, column=4, value=h.get('category', '')).font = TD_FONT
        w = h.get('weight')
        ws.cell(row=row, column=5, value=f'{w:.2f}%' if w is not None else '--').font = TD_FONT
        vc = ws.cell(row=row, column=6, value=h.get('market_value', 0))
        vc.font = TD_FONT
        vc.number_format = num_fmt
        row += 1
    row += 1

    def _alloc_section(title, headers, alloc_list):
        nonlocal row
        ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=9)
        ws.cell(row=row, column=1, value=title).font = SEC_FONT
        row += 1
        data_start = row + 1
        _table_header(ws, row, headers)
        row += 1
        for i, a in enumerate(alloc_list):
            ws.cell(row=row, column=1, value=i + 1).font = TD_FONT
            ws.cell(row=row, column=2, value=a['name']).font = TD_FONT
            vc = ws.cell(row=row, column=3, value=a['value'])
            vc.font = TD_FONT
            vc.number_format = num_fmt
            ws.cell(row=row, column=4, value=f"{a['pct']}%").font = TD_FONT
            row += 1
        data_end = row - 1
        return data_start, data_end

    alloc_sections = [
        ('ALLOCATION D\'ACTIFS', ['', 'Cat\u00e9gorie', 'Valeur', '% du Portefeuille'], data.get('asset_allocation') or [], 'asset'),
        ('R\u00c9PARTITION G\u00c9OGRAPHIQUE', ['', 'Pays', 'Valeur', '% du Portefeuille'], data.get('geo_allocation') or [], 'geo'),
        ('R\u00c9PARTITION SECTORIELLE', ['', 'Secteur', 'Valeur', '% du Portefeuille'], data.get('sector_allocation') or [], 'sector'),
    ]
    for title, headers, alloc_list, color_type in alloc_sections:
        if not alloc_list:
            continue

        ds, de = _alloc_section(title, headers, alloc_list)
        chart_ws_row = row
        colors = COLOR_MAP.get(color_type, FALLBACK_COLORS)

        doughnut = PieChart()
        doughnut.title = title
        doughnut.style = 10
        doughnut.width = 10
        doughnut.height = 10

        labels = Reference(ws, min_col=2, min_row=ds, max_row=de)
        values = Reference(ws, min_col=3, min_row=ds, max_row=de)
        doughnut.add_data(values, titles_from_data=False)
        doughnut.set_categories(labels)

        doughnut.dataLabels = DataLabelList()
        doughnut.dataLabels.showPercent = True
        doughnut.dataLabels.showVal = False
        doughnut.dataLabels.showCatName = True

        series = doughnut.series[0]
        for i, a in enumerate(alloc_list):
            pt = DataPoint(idx=i)
            pt.graphicalProperties.solidFill = colors[i % len(colors)]
            series.data_points.append(pt)

        ws.add_chart(doughnut, f'F{chart_ws_row}')
        row += 17

    # === CHARACTERISTICS ===
    ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=9)
    ws.cell(row=row, column=1, value='CARACT\u00c9RISTIQUES DU PORTEFEUILLE').font = SEC_FONT
    row += 1
    chars = [
        ('Nombre de positions', str(position_count)),
        ('Exposition actions', f'{equity_pct}%'),
        ('Exposition obligations', f'{bond_pct}%'),
        ('Score ESG moyen', f'{avg_esg:.1f}' if avg_esg else '--'),
        ('Devise de consolidation', fund_currency),
    ]
    for lbl, val in chars:
        ws.cell(row=row, column=2, value=lbl).font = TD_FONT
        ws.cell(row=row, column=3, value=val).font = BOLD
        row += 1
    row += 1

    # === DISCLAIMER ===
    ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=9)
    ws.cell(row=row, column=1, value='AVERTISSEMENT').font = Font(name='Calibri', size=9, bold=True, color='333333')
    row += 1
    ws.merge_cells(start_row=row, start_column=1, end_row=row + 2, end_column=9)
    disc = ws.cell(row=row, column=1, value=(
        'Les informations contenues dans ce document sont fournies \u00e0 titre indicatif. '
        'Elles ne constituent pas un conseil en investissement. Les performances pass\u00e9es '
        'ne pr\u00e9jugent pas des performances futures. SmartPMS \u2014 ' + generated_at
    ))
    disc.font = Font(name='Calibri', size=8, color='666666')
    disc.alignment = Alignment(wrap_text=True, vertical='top')


def generate_excel(data):
    import re, zipfile
    io = __import__('io')

    wb = Workbook()
    build_worksheet(wb.active, data)

    raw_buf = io.BytesIO()
    wb.save(raw_buf)
    raw_buf.seek(0)

    zip_in = zipfile.ZipFile(raw_buf, 'r')
    zip_out_buf = io.BytesIO()
    zip_out = zipfile.ZipFile(zip_out_buf, 'w', zipfile.ZIP_DEFLATED)

    for item in zip_in.infolist():
        content = zip_in.read(item.filename)
        if item.filename.endswith('.xml') and b'<pieChart' in content:
            content = content.replace(b'<pieChart', b'<doughnutChart')
            content = content.replace(b'</pieChart>', b'</doughnutChart>')
            content = re.sub(
                b'(<doughnutChart[^>]*>)',
                b'\\1<holeSize val="50"/>',
                content,
            )
        zip_out.writestr(item, content)

    zip_in.close()
    zip_out.close()
    return zip_out_buf.getvalue()
